# asci-art /output

## Description
### It's about creating a website whose goal is to transform normal text entered by the user into ASCII art text, which can be rendered in three styles (standard, shadow, thinkertoy).
## Authors
### BOUTAMGHARINE ANOUAR
## usage:
### comande go run main.go
